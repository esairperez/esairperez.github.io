<!DOCTYPE html>
<html lang="en">
	
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="assets/css/style.css">
		<link rel="shortcut icon" type="image/x-icon" href="assets/img/logo.png">
		<title>UP N GP</title>
	</head>


 <h1><img src="assets/img/logo.png" width="200">
      <!--<u><strong>Up N Go</u>--></h1>

<body class="sitemap">

<div class="site">
  <h1>SiteMap</h1>
</div>

<div id="sitelist">
    <p><a href="index.php">Home</a></p>
    <p><a href="contact.php">Contact</a></p>
    <p><a href="destinations.php">Destination</a></p>
    <p><a href="about.php">About</a></p>
</div>

<?php
require_once("footer.php");

?>
<!--
<footer>
  <a href="sitemap.html"><p><u>SiteMap</a></u></p>
</footer>-->







<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
   <script src="assets/js/bootstrap.min.js"></script>
</body>

</html>